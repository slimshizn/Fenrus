class MJPGStream {

    status(args) {
		let url = args.url;
		args.changeIcon(url);
        return;
    }
}

